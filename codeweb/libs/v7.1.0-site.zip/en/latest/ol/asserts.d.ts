/**
 * @param {*} assertion Assertion we expected to be truthy.
 * @param {number} errorCode Error code.
 */
export function assert(assertion: any, errorCode: number): void;
//# sourceMappingURL=asserts.d.ts.map